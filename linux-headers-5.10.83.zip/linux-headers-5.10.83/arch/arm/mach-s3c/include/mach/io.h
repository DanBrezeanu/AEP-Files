/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2020 Krzysztof Kozlowski <krzk@kernel.org>
 */

#ifdef CONFIG_ARCH_S3C24XX
#include "io-s3c24xx.h"
#endif
