/* Simple and naive GPIO driver.
 *
 * Directly reads/writes the MMIO (Memory mapped IO) registers of the PL061
 * GPIO Controller.
 *
 * The only supported operation is to set the OUTPUT direction of the PINs.
 * The direction of the 8 PINs of the controller are configured by the
 * GPIODIR register at offset 0x400 (starting from base) and use a  single
 * byte. A bit value of 0 means the PIN is set as INPUT, and a value of 1
 * means the direction is OUTPUT.
 *
 * To set a PIN 3 in OUTPUT mode, one can issue:
 *
 * sudo bash -c 'echo 3 > /dev/aep_gpio'
 */
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/io.h>
#include <linux/slab.h>

/*
 * Make sure there is no other Device Major on the target machine by
 * checking /proc/devices.
 */
#define AEP_GPIO_MAJOR 123

#define GPIODIR_OFFSET 0x...

/* The address of the GPIO controller */
#define GPIO_CHIP_BASE 0x...

/* How much memory is the device exposing */
#define GPIO_CHIP_REGION_SIZE 0x1000

/* The start address of the GPIO controller which the CPU can access */
void __iomem *aep_gpio_base_addr;

static int aep_gpio_open(struct inode *inode, struct file *file)
{
	printk("AEP_GPIO: device opened by process %s, PID %u\n",
			current->comm, current->pid);

	return 0;
}

static int aep_gpio_release(struct inode *inode, struct file *file)
{
	printk("AEP_GPIO: device closed\n");

	return 0;
}

static int aep_gpio_read(struct file *file, char __user *user_buffer, size_t size, loff_t *offset)
{
	int i, len;
	char *buf;
	unsigned long reg_value;
	void __iomem *direction_ptr;

	if (!size || *offset)
		return 0;

	buf = kmalloc(PAGE_SIZE, GFP_KERNEL);
	if (!buf)
		return -ENOMEM;

	direction_ptr = aep_gpio_base_addr + GPIODIR_OFFSET;

	/* Read one Byte */
	reg_value = readb(direction_ptr);

	len = 0;
	for (i = 0; i < 8; i++) {
		len += snprintf(
				buf + len, PAGE_SIZE, "PIN %u: %s\n",
			  	i,
				test_bit(i, &reg_value) ? "OUTPUT" : "INPUT"
			);
	}

	if (copy_to_user(user_buffer, buf, len) != 0) {
		kfree(buf);
		return -EFAULT;
	}

	*offset += len;

	kfree(buf);

	return *offset;
}

static int aep_gpio_write(struct file *file, const char __user *user_buffer, size_t size, loff_t *offset)
{
	char user_char;
	uint8_t user_pin;
	uint32_t prev_value, new_value;
	void __iomem *direction_ptr;

	/* Read the PIN number which the user echo-ed */
	if (copy_from_user(&user_char, user_buffer, sizeof(user_char)))
		return -EFAULT;

	/* Convert from ASCII character to integer */
	user_pin = user_char - '0';

	direction_ptr = aep_gpio_base_addr + GPIODIR_OFFSET;

	/* Read the previous PINs */
	prev_value = readb(direction_ptr);
	/* Set the new PIN */
	new_value = prev_value | BIT(user_pin);

	/* Write one Byte */
	writeb(new_value, direction_ptr);

	return size;
}

static struct file_operations aep_gpio_fops = {
	.open = aep_gpio_open,
	.release = aep_gpio_release,
	.read = aep_gpio_read,
	.write = aep_gpio_write,
};

static int __init aep_gpio_init(void)
{
	int ret;

	/* Register character device */
	ret = register_chrdev(AEP_GPIO_MAJOR, "aep_gpio", &aep_gpio_fops);
	if (ret < 0) {
		printk(KERN_ERR "AEP_GPIO: cannot register char device\n");
		return ret;
	}

	/*
	 * We need to access a Physical address (the device address) but the
	 * CPU can only access virtual addresses, so remap the device address.
	 */
	aep_gpio_base_addr = ioremap(GPIO_CHIP_BASE, GPIO_CHIP_REGION_SIZE);
	if (!aep_gpio_base_addr) {
		printk(KERN_ERR "AEP_GPIO: cannot access device memory\n");
		return -EIO;
	}

	return 0;
}

static void __exit aep_gpio_exit(void)
{
	unregister_chrdev(AEP_GPIO_MAJOR, "aep_gpio");

	iounmap(aep_gpio_base_addr);
}

module_init(aep_gpio_init);
module_exit(aep_gpio_exit);

MODULE_DESCRIPTION("Simple (as in incomplete) GPIO Driver");
MODULE_AUTHOR("AEP");
MODULE_LICENSE("GPL");
