#!/usr/bin/env python
# encoding: utf-8
import json
from flask import Flask, request, jsonify
from flask import Flask, render_template

from forms import AutomationForm

app = Flask(__name__)
app.secret_key = 'development key'

lightsState = "Off"
waterState = "Off"

@app.route('/')
def home():
    automationForm = AutomationForm()

    automationForm.currentTemperature = 20
    automationForm.desiredTemperature.data = 24
    automationForm.waterState = waterState
    automationForm.lightsState = lightsState

    return render_template('index.html', form=automationForm)

@app.route('/update', methods = ['POST'])
def update():

    global lightsState

    content = request.json

    elementId = content['id']
    action = content['action']

    automationForm = AutomationForm()

    if (elementId == "Lights"):
        if (action == "on"):
            lightsState = "On"
        elif (action == "off"):
            lightsState = "Off"
        elif (action == "toggle"):
            if (lightsState == "On"):
                lightsState = "Off"
            else:
                lightsState = "On"

        automationForm.lightsState = lightsState

    return "OK"

@app.route('/about/')
def about():
    return render_template('about.html')

app.run(debug=True, host='0.0.0.0')
