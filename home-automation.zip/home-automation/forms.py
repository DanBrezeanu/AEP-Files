from flask_wtf import Form  
from wtforms import StringField, IntegerField, SubmitField
from wtforms import validators, ValidationError  
  
class AutomationForm(Form):  
   currentTemperature = 0
   desiredTemperature = IntegerField("Desired Temperature: ",
           [validators.NumberRange(min=10, max=40)])

   waterState = 'Off'
   lightsState = 'Off'
